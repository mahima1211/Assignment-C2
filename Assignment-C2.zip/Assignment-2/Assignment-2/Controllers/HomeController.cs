﻿using Assignment_2.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.Extensions.Configuration;
namespace Assignment_2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            SchoolDbContext context = new SchoolDbContext(Assignment_2.Properties.Resources.ConnectionString);

            return View(context.GetAllTeachers());
        }
        [HttpGet("/Home/AddTeacher", Name = nameof(AddTeacher))]
        public IActionResult AddTeacher()
        {
           

            return View();
        }

        [HttpGet("/{teacherId}/delete", Name = nameof(Index))]
        public IActionResult Index(Teacher m)
        {
            SchoolDbContext context = new SchoolDbContext(Assignment_2.Properties.Resources.ConnectionString);
            context.deleteTeacher(m.teacherId);
            return View(context.GetAllTeachers());
        }

        [HttpPost("/Home/Create", Name = nameof(saveTeacher))]
        public IActionResult saveTeacher(Teacher m)
        {
            Teacher t = new Teacher();
            t.teacherlName = m.teacherlName;
            t.teacherFname = m.teacherFname;
            t.employeenumber = m.employeenumber;
            t.salary = m.salary;
          
            SchoolDbContext context = new SchoolDbContext(Assignment_2.Properties.Resources.ConnectionString);
            context.addTeacher(m);
            return View(context.GetAllTeachers());
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}