﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
namespace Assignment_2.Models
{
    public class SchoolDbContext
    {
        public string ConnectionString { get; set; }

        public SchoolDbContext(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnectionString);
        }
        public List<Teacher> GetAllTeachers()
        {
            List<Teacher> list = new List<Teacher>();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("select * from teachers", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Teacher()
                        {
                            teacherId = Convert.ToInt32(reader["teacherid"]),
                            teacherFname = reader["teacherfname"].ToString(),
                            teacherlName = reader["teacherlname"].ToString(),
                            employeenumber = reader["employeenumber"].ToString(),
                            hiredate = reader["hiredate"].ToString(),
                            salary = Convert.ToDecimal(reader["salary"])
                        });
                    }
                }
            }

            return list;
        }
        public void deleteTeacher(int id)
        {
            MySqlConnection conn = GetConnection();
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("DELETE FROM teachers WHERE teacherid="+id, conn);
           cmd.ExecuteReader();
        }
        public void addTeacher(Teacher obj)
        {
            MySqlConnection conn = GetConnection();
            conn.Open();
            String sql = "INSERT INTO teachers (teacherfname, teacherlname, employeenumber, hiredate,salary)" +
                    "VALUES(" +"'"+ obj.teacherFname + "'"+ ","+"'" + obj.teacherlName+"'" + ","  +"'" + obj.employeenumber+"'" + ", CURRENT_TIMESTAMP" + "," + obj.salary+")";
            MySqlCommand cmd = 
                new MySqlCommand(sql,conn);
                cmd.ExecuteReader();
        }
    }
}
